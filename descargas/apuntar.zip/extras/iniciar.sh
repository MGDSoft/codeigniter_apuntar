#!/bin/sh

cd $(cd "$(dirname "$0")"; pwd)"/.."

java -jar apuntar.jar &
