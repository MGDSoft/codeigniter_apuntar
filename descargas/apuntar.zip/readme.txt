####################################################################
####	Bienvenido al programa de escritorio de apuntar.net	####
####################################################################

***** Instalación **************************************************
*
* - Desistalar el zip dentro de cualquier carpeta
*
*
***** Ejecutarlo ***************************************************
*
* - Abre la consola y ve a la carpeta donde este la instalación y ejecuta java -jar apuntar.jar 
*  o ejecutando el sh inicial que hay en la carpeta extras
*
* - Si quieres abrirlo al arrancar el ordenar y que se quede minimizado -java -jar apuntar.jar min, 
*  PARA LINUX: tambien tienes en extras la posibilidad de copiar el apuntar.desktop (modifica el 
*  documento para la ruta del icono y el ejecutable para tus rutas) y guardalo en ~/.config/autostart
*
* - Para ejecutarlo mediante algun tipo de dock (como cairo en linux) o ejecutable que llame a shell 
*  cd /<DIRECTORIO DE APUNTAR> && java -jar apuntar.jar
*
********************************************************************

Para más información no dudes visitar http://apuntar.net


####################################################################
######	Desarrollo realizado por MGDSoftware.es		############
####################################################################



