registro
<?php echo form_open('/forms/registro_form' ); ?></form>
<form id='registro_form' action="javascript:enviar_form_ajax('registro_validacion()','registro_form','/forms/registro_form','resultado_form','')" method="post" accept-charset="utf-8">
<table>
<tr><td><?= $this->lang->line('correo') ?></td><td><input type="text" name="correo" value="" id="correo"></td></tr>
<tr><td><?= $this->lang->line('contrasena') ?></td><td><input type="text" name="contrasena" value="" id="contrasena"></td></tr>
<tr><td><?= $this->lang->line('recontrasena') ?></td><td><input type="text" name="recontrasena" value="" id="recontrasena"></td></tr>
<tr><td><?= $this->lang->line('nombre') ?></td><td><input type="text" name="nombre" value="" id="nombre"></td></tr>
<tr><td><?= $this->lang->line('apellidos') ?></td><td><input type="text" name="apellidos" value="" id="apellidos"></td></tr>
<tr><td><?= $this->lang->line('titulo') ?></td><td><input type="text" name="titulo" value="" id="titulo"></td></tr>
<tr><td><?= $this->lang->line('nombre_unico') ?></td><td><input type="text" name="nombre_unico" value="" id="nombre_unico"></td></tr>
<tr><td><?= $this->lang->line('uso_horario') ?></td><td><input type="text" name="uso_horario" value="" id="uso_horario"></td></tr>
<tr><td colspan='2' align='right'><input type="submit" name="enviar" value="enviar"></td></tr>
</table>
<input name="iehack" type="hidden" value="&#9760;" />
<div id='resultado_form' style='border:1px solid red'></div>
</form>

