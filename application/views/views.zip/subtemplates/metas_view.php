<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="es" xmlns:fb="http://www.facebook.com/2008/fbml">
<head> 
<title><?= $titulo ?></title>
<meta name="title" content="<?= $titulo ?> | myEquipo.com"/>
<meta property="og:title" content="<?= $titulo ?>"/>
<meta property="og:site_name" content=""/>
<meta name="description" content="<?= $descripcion ?>" lang="es"/>
<meta http-equiv="Content-Language" content="es-ES"/>
<meta name="author" content="MGDSoftware"/>
<link rev="made" href="mailto:administracion@myequipo.com"/>
<meta name="locality" content="Madrid, Espa�a"/>
<meta name="distribution" content="global"/>
<meta name="language" content="es-ES"/>
<meta http-equiv="Pragma" content="no-cache"/>
<meta name="resource-type" content="document"/>
<meta http-equiv="Content-Type" content="text/html; charset=UTF8" />
<link rel="shortcut icon" href="imagenesWeb/myequipo.ico" /> 
<base href="<?=base_url();?>">
<script src="<?= PATH_JS ?>mootools-core-1.4.2.js" type="text/javascript"></script>   
<script src="<?= PATH_JS ?>scriptbase.js" type="text/javascript"></script>   
<script src="<?= PATH_JS ?>validacion_forms.js" type="text/javascript"></script>   